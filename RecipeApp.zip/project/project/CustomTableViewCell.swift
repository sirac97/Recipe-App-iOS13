//
//  CustomTableViewCell.swift
//  project
//
//  Created by CTIS Student on 5.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var mTitle: UILabel!
    @IBOutlet weak var mDuration: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
