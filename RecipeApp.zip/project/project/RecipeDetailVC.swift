//
//  RecipeDetailVC.swift
//  RecipeApplication
//
//  Created by CTIS Student on 1.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class RecipeDetailVC: UIViewController {
    
    @IBOutlet weak var mName: UITextField!
    @IBOutlet weak var mDuration: UITextField!
    @IBOutlet weak var mDescription: UITextView!
    @IBOutlet weak var mIngredients: UITextView!
    @IBOutlet weak var mSteps: UITextView!
    @IBOutlet weak var mButton: UIButton!
    
    var mTableView: UITableView?
    
    var recipe: Recipe!
    var isEditingMode = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        mName.isUserInteractionEnabled = false
        mName.borderStyle = .none
        mDuration.isUserInteractionEnabled = false
        mDuration.borderStyle = .none
        mDescription.isEditable = false
        mIngredients.isEditable = false
        mSteps.isEditable = false
        
        mIngredients.layer.cornerRadius = 10
        mSteps.layer.cornerRadius = 10
        mDescription.layer.cornerRadius = 10
        
        if let mRecipe = recipe {
            mName.text = mRecipe.name
            mDuration.text = "\(mRecipe.duration)"
            mDescription.text = mRecipe.recipeDescription
            mIngredients.text = mRecipe.ingredients
            mSteps.text = mRecipe.steps
        }
    }
    
    @IBAction func onButtonClickHandler(_ sender: UIButton) {
        if isEditingMode {
            isEditingMode=false
            mButton.setTitle("Close", for: .normal)
            mButton.setTitleColor(.red, for: .normal)
            mName.isUserInteractionEnabled = false
            mName.borderStyle = .none
            mDuration.isUserInteractionEnabled = false
            mDuration.borderStyle = .none
            mDescription.isEditable = false
            mIngredients.isEditable = false
            mSteps.isEditable = false
            updateItem(mName.text ?? "", recipeDescription: mDescription.text ?? "", duration: mDuration.text ?? "0", ingredients: mIngredients.text ?? "", steps: mSteps.text ?? "", category: recipe.category!)
        }else{
            if let tableView=mTableView {
                tableView.reloadData()
            }
            dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func onDeleteHandler(_ sender: UIButton) {
        let mAlert = UIAlertController(title: "Confirm?",
                                       message: "Are you sure you want to delete recipe?",
                                       preferredStyle: .alert)
        
        mAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        mAlert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { (UIAlertAction) in
            self.deleteItem()
            if let tableView=self.mTableView {
                tableView.reloadData()
            }
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(mAlert, animated: true)
    }
    
    @IBAction func onEditHandler(_ sender: UIButton) {
        isEditingMode=true
        mName.isUserInteractionEnabled = true
        mName.borderStyle = .roundedRect
        mDuration.isUserInteractionEnabled = true
        mDuration.borderStyle = .roundedRect
        mDescription.isEditable = true
        mIngredients.isEditable = true
        mSteps.isEditable = true
        mButton.setTitle("Save", for: .normal)
        mButton.setTitleColor(.systemBlue, for: .normal)
    }
    
    func updateItem(_ name : String, recipeDescription: String, duration: String, ingredients: String, steps: String, category: String){
        
        let recipeDict=["name": name, "recipeDescription": recipeDescription, "duration": NumberFormatter().number(from: duration)!, "ingredients": ingredients, "steps": steps, "category": category] as [String : Any]
        
        recipe.setValuesForKeys(recipeDict)
        
        recipe.name=name
        recipe.recipeDescription = recipeDescription
        recipe.duration=Double(truncating: NumberFormatter().number(from: duration)!)
        recipe.ingredients=ingredients
        recipe.steps=steps
        recipe.category=category
        
        save()
    }
    
    func deleteItem(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        context.delete(recipe)
        save()
    }
    
    func save() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}
