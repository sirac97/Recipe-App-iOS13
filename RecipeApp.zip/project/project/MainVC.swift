//
//  ViewController.swift
//  RecipeApplication
//
//  Created by CTIS Student on 1.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
import AVFoundation

class MainVC: UIViewController {
    
    var mDataSource = DataSource()
    var audioPlayer: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let hasLaunchedKey = "HasLaunched"
        let defaults = UserDefaults.standard
        let hasLaunched = defaults.bool(forKey: hasLaunchedKey)

            if !hasLaunched {
                defaults.set(true, forKey: hasLaunchedKey)
                mDataSource.populate()
            }
        
        playSound()
        
        assignbackground()
    }
    
    func playSound() {
        
        let soundURL = Bundle.main.url(forResource: "chopping", withExtension: "mp3")
        audioPlayer = try! AVAudioPlayer(contentsOf: soundURL!)
        
        audioPlayer.play()
    }
    
    func assignbackground(){
        let background = UIImage(named: "bg.png")

        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIView.ContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubviewToBack(imageView)
    }

}
