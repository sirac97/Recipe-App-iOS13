//
//  AddRecipeVC.swift
//  RecipeApplication
//
//  Created by CTIS Student on 1.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
import CoreData

class AddRecipeVC: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfDuration: UITextField!
    @IBOutlet weak var tvIngredients: UITextView!
    @IBOutlet weak var tvSteps: UITextView!
    @IBOutlet weak var tvDescription: UITextView!
    @IBOutlet weak var mPickerView: UIPickerView!
    
    var myDataSource=DataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        myDataSource.loadData()
        tvIngredients.layer.cornerRadius = 10
        tvSteps.layer.cornerRadius = 10
        tvDescription.layer.cornerRadius = 10
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return myDataSource.numberOfCategories()
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        return NSAttributedString(string: myDataSource.getCategoryLabelAtIndex(index: row), attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
    }
    
    @IBAction func btnAddHandler(_ sender: UIButton) {
        let name=tfName.text
        let duration=tfDuration.text
        let ingredients=tvIngredients.text
        let steps=tvSteps.text
        let description=tvDescription.text
        
        if(name == "" || duration == "" || ingredients == "" || steps == ""){
            let mAlert = UIAlertController(title: "Error",
                                           message: "Input(s) cannot be empty",
                                           preferredStyle: .alert)
            mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
            self.present(mAlert, animated: true)
        }else{
            let category = myDataSource.mRecipeList[mPickerView.selectedRow(inComponent: 0)].category;
            
            saveNewItem(name!, recipeDescription: description!, duration: duration!, ingredients: ingredients!, steps: steps!, category:category!)
            
            let mAlert = UIAlertController(title: "Success",
                                           message: "Item Added",
                                           preferredStyle: .alert)
            mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: { (UIAlertAction) in
                self.navigationController?.popViewController(animated: true)
            }))
            
            self.present(mAlert, animated: true)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func saveNewItem(_ name : String, recipeDescription: String, duration: String, ingredients: String, steps: String, category: String) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let _ = Recipe.createInManagedObjectContext(context,
                                                    name: name, recipeDescription: recipeDescription, duration: NumberFormatter().number(from: duration)!, ingredients: ingredients, steps: steps, category: category)
        
        save()
    }
    
    func save() {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do {
            try context.save()
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
}
