//
//  RecipesVC.swift
//  RecipeApplication
//
//  Created by CTIS Student on 1.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class RecipesVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var recipesTableView: UITableView!
    
    let myDataSource = DataSource()
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return myDataSource.numberOfCategories()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myDataSource.numberOfItemsInEachCategory(index: section)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let label : UILabel = UILabel()
        
        label.text = myDataSource.getCategoryLabelAtIndex(index: section)
        label.font = UIFont(name: "HelveticaNeue-Bold", size: 28.0)
        label.textColor = UIColor.white
        label.backgroundColor = UIColor.red
        label.textAlignment = .center
        
        return label
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.sendToDetail))
        tapGesture.numberOfTapsRequired = 2
        cell.addGestureRecognizer(tapGesture)
        
        let recipes: [Recipe] = myDataSource.itemsInCategory(index: indexPath.section)
        
        let recipe = recipes[indexPath.row]
        
        cell.mTitle?.text = recipe.name
        cell.mDuration?.text = "\(recipe.duration) mins"
        
        return cell
    }
    
    @objc func sendToDetail(){
        performSegue(withIdentifier: "detail", sender: self)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        myDataSource.loadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail" {
            if let indexPath = getIndexPathForSelectedRow() {
                let recipe = myDataSource.itemsInCategory(index: indexPath.section)[indexPath.row]
                
                let detailViewController = segue.destination as! RecipeDetailVC
                
                detailViewController.recipe = recipe
                detailViewController.mTableView = recipesTableView
            }
        }
    }
    
    func getIndexPathForSelectedRow() -> IndexPath? {
        var indexPath: IndexPath?
        
        if recipesTableView.indexPathForSelectedRow!.count > 0 {
            indexPath = recipesTableView.indexPathsForSelectedRows![0] as IndexPath
        }
        return indexPath
    }

}
