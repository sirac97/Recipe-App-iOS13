//
//  ViewController.swift
//  project
//
//  Created by CTIS Student on 4.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

