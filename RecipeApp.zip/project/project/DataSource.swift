    import Foundation
    import CoreData
    import UIKit
    
    class DataSource {
        var mRecipeList: [Recipe] = []
        var categories: [String] = []
        
        func populate() {
            if let mURL = URL(string: "https://jsonkeeper.com/b/YOAR") {
                if let data = try? Data(contentsOf: mURL) {
                    
                    // https://www.dotnetperls.com/guard-swift
                    guard let json = try? JSON(data: data) else {
                        print("Error with JSON")
                        return
                    }
                    
                    for index in 0..<json["items"].count {
                        let name = json["items"][index]["name"].string!
                        let category = json["items"][index]["category"].string!
                        let description = json["items"][index]["description"].string!
                        let duration = json["items"][index]["duration"].string!
                        let ingredients = json["items"][index]["ingredients"].string!
                        let steps = json["items"][index]["steps"].string!
                        
                        let item = createItem(name, recipeDescription: description, duration: duration, ingredients: ingredients, steps: steps, category: category)
                        
                        mRecipeList.append(item)
                        save()
                        
                        if !categories.contains(category) {
                            categories.append(category)
                        }
                    }
                }
                else {
                    print("Data error")
                }
            }
            else {
                print("Error")
            }
        }
        
        func numberOfItemsInEachCategory(index: Int) -> Int {
            return itemsInCategory(index: index).count
        }
        
        func numberOfCategories() -> Int {
            return categories.count
        }
        
        func getCategoryLabelAtIndex(index: Int) -> String {
            return categories[index]
        }
        
        func itemsInCategory(index: Int) -> [Recipe] {
            let item = categories[index]
            
            let filteredItems = mRecipeList.filter { (recipe: Recipe) -> Bool in
                return recipe.category == item
            }
            return filteredItems
        }
        
        func loadData(){
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Recipe")
            
            do {
                let results = try context.fetch(fetchRequest)
                mRecipeList = results as! [Recipe]
                
                for index in 0..<mRecipeList.count{
                    let category=mRecipeList[index].category!
                    if !categories.contains(category) {
                        categories.append(category)
                    }
                }
                
            } catch let error as NSError {
                print("Could not fetch \(error), \(error.userInfo)")
            }
        }
        
        func createItem(_ name : String, recipeDescription: String, duration: String, ingredients: String, steps: String, category: String) -> Recipe {
            
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            
            let item = Recipe.createInManagedObjectContext(context,
                                                        name: name, recipeDescription: recipeDescription, duration: NumberFormatter().number(from: duration)!, ingredients: ingredients, steps: steps, category: category)
            
            return item
        }
        
        func save() {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            do {
                try context.save()
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
        
    }
