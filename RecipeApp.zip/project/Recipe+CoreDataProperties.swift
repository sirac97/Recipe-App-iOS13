//
//  Recipe+CoreDataProperties.swift
//  project
//
//  Created by CTIS Student on 4.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData


extension Recipe {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Recipe> {
        return NSFetchRequest<Recipe>(entityName: "Recipe")
    }

    @NSManaged public var name: String?
    @NSManaged public var recipeDescription: String?
    @NSManaged public var duration: Double
    @NSManaged public var steps: String?
    @NSManaged public var ingredients: String?
    @NSManaged public var category: String?

}
