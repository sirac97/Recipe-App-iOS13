//
//  Recipe+CoreDataClass.swift
//  project
//
//  Created by CTIS Student on 4.01.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Recipe)
public class Recipe: NSManagedObject {
    class func createInManagedObjectContext(_ context: NSManagedObjectContext, name: String, recipeDescription: String, duration: NSNumber, ingredients: String, steps: String, category: String) -> Recipe {
        let recipeObject = NSEntityDescription.insertNewObject(forEntityName: "Recipe", into: context) as! Recipe
        recipeObject.name = name
        recipeObject.recipeDescription = recipeDescription
        recipeObject.duration=Double(truncating: duration)
        recipeObject.ingredients=ingredients
        recipeObject.steps=steps
        recipeObject.category=category
        return recipeObject
    }
    
}
